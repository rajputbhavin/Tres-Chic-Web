import birthday119 from "@/assets/social-celebrations/00-corea-s-50th-birthday-119.webp.asset.json";
import birthday14 from "@/assets/social-celebrations/01-corea-s-50th-birthday-14.webp.asset.json";
import birthday15 from "@/assets/social-celebrations/02-corea-s-50th-birthday-15.webp.asset.json";
import birthday21 from "@/assets/social-celebrations/03-corea-s-50th-birthday-21.webp.asset.json";
import birthday22 from "@/assets/social-celebrations/04-corea-s-50th-birthday-22.webp.asset.json";
import birthday3 from "@/assets/social-celebrations/05-corea-s-50th-birthday-3.webp.asset.json";
import birthday31 from "@/assets/social-celebrations/06-corea-s-50th-birthday-31.webp.asset.json";
import birthday4 from "@/assets/social-celebrations/07-corea-s-50th-birthday-4.webp.asset.json";
import birthday40 from "@/assets/social-celebrations/08-corea-s-50th-birthday-40.webp.asset.json";
import birthday41 from "@/assets/social-celebrations/09-corea-s-50th-birthday-41.webp.asset.json";
import birthday42 from "@/assets/social-celebrations/10-corea-s-50th-birthday-42.webp.asset.json";
import birthday53 from "@/assets/social-celebrations/11-corea-s-50th-birthday-53.webp.asset.json";
import birthday63 from "@/assets/social-celebrations/12-corea-s-50th-birthday-63.webp.asset.json";
import birthday68 from "@/assets/social-celebrations/13-corea-s-50th-birthday-68.webp.asset.json";
import birthday8 from "@/assets/social-celebrations/14-corea-s-50th-birthday-8.webp.asset.json";
import birthday9 from "@/assets/social-celebrations/15-corea-s-50th-birthday-9.webp.asset.json";
import mitzvahSign from "@/assets/social-celebrations/16-dsc-2077.webp.asset.json";
import mitzvahRoom from "@/assets/social-celebrations/17-dsc-3478.webp.asset.json";
import mitzvahTable from "@/assets/social-celebrations/18-dsc-3496.webp.asset.json";
import mitzvahDining from "@/assets/social-celebrations/19-dsc-3525.webp.asset.json";
import mitzvahReception from "@/assets/social-celebrations/20-dsc-3534.webp.asset.json";
import showerCastle from "@/assets/social-celebrations/21-img-5740.webp.asset.json";
import showerRoom from "@/assets/social-celebrations/22-img-8487.webp.asset.json";
import showerCarriage from "@/assets/social-celebrations/23-img-8496.webp.asset.json";
import showerDesserts from "@/assets/social-celebrations/24-img-8504.webp.asset.json";
import showerTable from "@/assets/social-celebrations/25-img-8507.webp.asset.json";
import showerDetails from "@/assets/social-celebrations/26-img-8987.webp.asset.json";

export const socialCelebrationPhotos = {
  birthday119: birthday119.url, birthday14: birthday14.url, birthday15: birthday15.url,
  birthday21: birthday21.url, birthday22: birthday22.url, birthday3: birthday3.url,
  birthday31: birthday31.url, birthday4: birthday4.url, birthday40: birthday40.url,
  birthday41: birthday41.url, birthday42: birthday42.url, birthday53: birthday53.url,
  birthday63: birthday63.url, birthday68: birthday68.url, birthday8: birthday8.url,
  birthday9: birthday9.url, mitzvahSign: mitzvahSign.url, mitzvahRoom: mitzvahRoom.url,
  mitzvahTable: mitzvahTable.url, mitzvahDining: mitzvahDining.url,
  mitzvahReception: mitzvahReception.url, showerCastle: showerCastle.url,
  showerRoom: showerRoom.url, showerCarriage: showerCarriage.url,
  showerDesserts: showerDesserts.url, showerTable: showerTable.url,
  showerDetails: showerDetails.url,
} as const;