import { Eyebrow } from "@/components/ui/Eyebrow";
import { Reveal } from "@/components/ui/Reveal";

/** Editorial page hero used by every inner page. */
export function PageHero({
  eyebrow,
  headline,
  body,
  image,
  imageAlt,
overlay = true,
}: {
  eyebrow: string;
  headline: string;
  body?: string;
  image?: string;
  imageAlt?: string;
  /** Slight dark scrim over the image to keep ivory text readable. */
  overlay?: boolean;
}) {
  return (
    <header className="relative isolate overflow-hidden bg-emerald text-ivory">
      {image ? (
        <img
          src={image}
          alt={imageAlt ?? ""}
          className="absolute inset-0 size-full object-cover"
        />
      ) : null}
      {overlay ? (
        <div className="absolute inset-0 bg-ink/30" aria-hidden />
      ) : null}
      <div className="relative mx-auto w-full max-w-6xl px-6 pt-36 pb-20 md:px-10 md:pt-48 md:pb-28">
        <Reveal>
          <Eyebrow tone="ivory">{eyebrow}</Eyebrow>
          <h1 className="display-xl mt-6 max-w-3xl text-balance">{headline}</h1>
          {body ? <p className="lede mt-7 max-w-xl text-ivory/80">{body}</p> : null}
        </Reveal>
      </div>
    </header>
  );
}
