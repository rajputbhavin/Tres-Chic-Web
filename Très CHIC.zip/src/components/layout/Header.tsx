import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";

import { primaryNav, site, utilityNav } from "@/data/site";
import { useHeaderScrollState } from "@/hooks/useHeaderScrollState";
import { cn } from "@/lib/utils";

/**
 * Fixed header. Transparent over the homepage hero, ivory everywhere else and
 * once the visitor scrolls.
 */
export function Header() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const scrolled = useHeaderScrollState();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const transparent = pathname === "/" && !scrolled;

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-colors duration-500",
        transparent ? "bg-transparent" : "border-b border-border bg-background/95 backdrop-blur-sm",
      )}
    >
      <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-6 px-6 py-5 md:px-10">
        <Link
          to="/"
          className={cn(
            "font-display leading-none transition-colors",
            transparent ? "text-ivory" : "text-emerald",
          )}
          aria-label={`${site.name}, home`}
        >
          <span className="block text-xl tracking-[0.18em] uppercase md:text-2xl">
            {site.shortName}
          </span>
          <span
            className={cn(
              "mt-1 block text-[0.5625rem] tracking-[0.34em] uppercase",
              transparent ? "text-ivory/70" : "text-taupe",
            )}
          >
            Event Planning &amp; Design
          </span>
<span
            className={cn(
              "mt-1.5 block text-left font-display text-[0.75rem] normal-case italic",
              transparent ? "text-ivory/85" : "text-gold",
            )}
          >
            by Mariane Fahmy
          </span>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex xl:gap-8" aria-label="Primary">
          {primaryNav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "text-[0.75rem] font-medium tracking-[0.16em] uppercase transition-colors",
                transparent
                  ? "text-ivory/85 hover:text-gold"
                  : "text-foreground/75 hover:text-emerald",
              )}
              activeOptions={{ exact: item.to === "/" }}
              activeProps={{ className: transparent ? "text-gold" : "text-emerald" }}
            >
              {item.label}
            </Link>
          ))}
          <Link
            to="/start-planning"
            className={cn(
              "px-6 py-3 text-[0.75rem] font-semibold tracking-[0.16em] uppercase transition-colors",
              transparent
                ? "border border-ivory/60 text-ivory hover:border-gold hover:text-gold"
                : "bg-emerald text-ivory hover:bg-emerald-light",
            )}
          >
            Start Planning
          </Link>
        </nav>

        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
          className={cn("lg:hidden", transparent && !open ? "text-ivory" : "text-emerald")}
        >
          {open ? <X className="size-6" aria-hidden /> : <Menu className="size-6" aria-hidden />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-border bg-background px-6 pt-6 pb-10 lg:hidden">
          <nav className="flex flex-col gap-5" aria-label="Mobile">
            {primaryNav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="text-sm tracking-[0.16em] text-foreground uppercase"
              >
                {item.label}
              </Link>
            ))}
            <span className="mt-2 h-px w-10 bg-gold" aria-hidden />
            {utilityNav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="text-xs tracking-[0.16em] text-muted-foreground uppercase"
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/start-planning"
              className="mt-4 bg-emerald px-6 py-4 text-center text-[0.75rem] font-semibold tracking-[0.16em] text-ivory uppercase"
            >
              Start Planning
            </Link>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
