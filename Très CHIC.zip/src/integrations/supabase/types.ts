export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      faqs: {
        Row: {
          answer: string
          category: string | null
          created_at: string
          display_order: number
          id: string
          is_published: boolean
          needs_confirmation: boolean
          question: string
          updated_at: string
        }
        Insert: {
          answer: string
          category?: string | null
          created_at?: string
          display_order?: number
          id?: string
          is_published?: boolean
          needs_confirmation?: boolean
          question: string
          updated_at?: string
        }
        Update: {
          answer?: string
          category?: string | null
          created_at?: string
          display_order?: number
          id?: string
          is_published?: boolean
          needs_confirmation?: boolean
          question?: string
          updated_at?: string
        }
        Relationships: []
      }
      inquiries: {
        Row: {
          celebration_type: string | null
          created_at: string
          date_undecided: boolean
          email: string
          event_date: string | null
          guest_range: string | null
          id: string
          location: string | null
          names: string
          notes: string | null
          phone: string | null
          referral_source: string | null
          support_level: string | null
          traditions: string | null
          updated_at: string
        }
        Insert: {
          celebration_type?: string | null
          created_at?: string
          date_undecided?: boolean
          email: string
          event_date?: string | null
          guest_range?: string | null
          id?: string
          location?: string | null
          names: string
          notes?: string | null
          phone?: string | null
          referral_source?: string | null
          support_level?: string | null
          traditions?: string | null
          updated_at?: string
        }
        Update: {
          celebration_type?: string | null
          created_at?: string
          date_undecided?: boolean
          email?: string
          event_date?: string | null
          guest_range?: string | null
          id?: string
          location?: string | null
          names?: string
          notes?: string | null
          phone?: string | null
          referral_source?: string | null
          support_level?: string | null
          traditions?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      media_assets: {
        Row: {
          alt_text: string
          caption: string | null
          category: string
          created_at: string
          display_order: number
          file_name: string
          height: number | null
          id: string
          is_published: boolean
          orientation: string | null
          slug: string
          source_page: string | null
          source_url: string | null
          tradition: string | null
          updated_at: string
          width: number | null
        }
        Insert: {
          alt_text: string
          caption?: string | null
          category: string
          created_at?: string
          display_order?: number
          file_name: string
          height?: number | null
          id?: string
          is_published?: boolean
          orientation?: string | null
          slug: string
          source_page?: string | null
          source_url?: string | null
          tradition?: string | null
          updated_at?: string
          width?: number | null
        }
        Update: {
          alt_text?: string
          caption?: string | null
          category?: string
          created_at?: string
          display_order?: number
          file_name?: string
          height?: number | null
          id?: string
          is_published?: boolean
          orientation?: string | null
          slug?: string
          source_page?: string | null
          source_url?: string | null
          tradition?: string | null
          updated_at?: string
          width?: number | null
        }
        Relationships: []
      }
      reviews: {
        Row: {
          attribution: string
          created_at: string
          display_order: number
          excerpt: string
          id: string
          is_published: boolean
          needs_confirmation: boolean
          platform: string | null
          updated_at: string
          wedding_type: string | null
        }
        Insert: {
          attribution: string
          created_at?: string
          display_order?: number
          excerpt: string
          id?: string
          is_published?: boolean
          needs_confirmation?: boolean
          platform?: string | null
          updated_at?: string
          wedding_type?: string | null
        }
        Update: {
          attribution?: string
          created_at?: string
          display_order?: number
          excerpt?: string
          id?: string
          is_published?: boolean
          needs_confirmation?: boolean
          platform?: string | null
          updated_at?: string
          wedding_type?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
